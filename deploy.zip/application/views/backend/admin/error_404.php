<div class="page-error-404">
	
	
	<div class="error-symbol">
		<i class="entypo-attention"></i>
	</div>
	
	<div class="error-text">
		<h2>404</h2>
		<p>Page not found!</p>
	</div>
	
		
		<br>
		<br>
		
		<br>
		<br>
	
</div>